document.getElementById('start-game').addEventListener('click', startGame);
document.getElementById('participants-btn').addEventListener('click', toggleParticipantsModal);
document.getElementById('view-participants').addEventListener('click', viewParticipants);
document.getElementById('confirm-selection').addEventListener('click', showPrize);
document.getElementById('back-to-game').addEventListener('click', backToGame);

let selectedNumbers = [];
let participants = [];
let currentSelections = [];

function startGame() {
    const name = document.getElementById('player-name').value.trim();
    if (name === '') {
        alert('Por favor, digite seu nome para começar o jogo.');
        return;
    }

    // Esconde a seção de nome e mostra a seção de números
    document.getElementById('name-section').classList.add('hidden');
    document.getElementById('number-section').classList.remove('hidden');
    generateNumbers();
}

function generateNumbers() {
    const numberGrid = document.getElementById('number-grid');
    numberGrid.innerHTML = '';

    for (let i = 1; i <= 100; i++) {
        const numberElement = document.createElement('div');
        numberElement.className = 'number';
        numberElement.innerText = i;
        numberElement.addEventListener('click', () => selectNumber(i, numberElement));
        numberGrid.appendChild(numberElement);
    }
}

function selectNumber(number, element) {
    if (selectedNumbers.includes(number)) {
        alert('ESTE NÚMERO JÁ FOI ESCOLHIDO');
        return;
    }

    if (currentSelections.includes(number)) {
        // Se o número já está selecionado, deseleciona
        currentSelections = currentSelections.filter(num => num !== number);
        element.classList.remove('selected');
    } else {
        if (currentSelections.length < 2) {
            currentSelections.push(number);
            element.classList.add('selected');
        } else {
            alert('Você só pode escolher até dois números.');
        }
    }
}

function showPrize() {
    if (currentSelections.length === 0) {
        alert('Por favor, escolha pelo menos um número.');
        return;
    }

    const name = document.getElementById('player-name').value.trim();
    const prizes = currentSelections.map(number => getDiaperType(number));
    const prizeMessage = `PARABÉNS, ${name}! Você ganhou: ${prizes.join(' e ')}`;

    document.getElementById('prize-message').innerText = prizeMessage;
    document.getElementById('number-section').classList.add('hidden');
    document.getElementById('prize-section').classList.remove('hidden');

    currentSelections.forEach(number => {
        selectedNumbers.push(number);
        participants.push({ name, number, diaperType: getDiaperType(number) });
    });

    currentSelections = [];
}

function getDiaperType(number) {
    if (number >= 1 && number <= 10) {
        return 'FRALDA P';
    } else if (number >= 11 && number <= 40) {
        return 'FRALDA M';
    } else if (number >= 41 && number <= 70) {
        return 'FRALDA G';
    } else {
        return 'FRALDA GG';
    }
}

function toggleParticipantsModal() {
    document.getElementById('participants-modal').classList.toggle('hidden');
}

function viewParticipants() {
    const password = document.getElementById('password-input').value;
    if (password !== '1234') {
        alert('Senha incorreta!');
        return;
    }

    const participantsList = document.getElementById('participants-list');
    participantsList.innerHTML = '';

    participants.forEach(participant => {
        const listItem = document.createElement('p');
        listItem.innerText = `${participant.name} escolheu o número ${participant.number} e ganhou: ${participant.diaperType}`;
        participantsList.appendChild(listItem);
    });
}

function backToGame() {
    document.getElementById('prize-section').classList.add('hidden');
    document.getElementById('number-section').classList.remove('hidden');
}

